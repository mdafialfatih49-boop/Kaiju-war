# Membuat 7 tekstur kaiju (128x128) tanpa library tambahan.
import random, zlib, struct, os

KINDS = {  # id: (warna dasar, warna duri/bercahaya, warna mata)
    "atomic_titan":    ((45, 50, 55),  (90, 200, 255), (255, 240, 120)),
    "bladehead":       ((35, 40, 75),  (180, 200, 230), (0, 230, 255)),
    "stormback":       ((60, 60, 90),  (255, 240, 80), (255, 255, 255)),
    "frostjaw":        ((110, 150, 170), (230, 250, 255), (120, 220, 255)),
    "magma_rex":       ((60, 25, 20),  (255, 120, 20), (255, 200, 0)),
    "venomtail":       ((30, 70, 40),  (170, 255, 60), (200, 255, 0)),
    "shadow_colossus": ((15, 15, 25),  (160, 60, 220), (255, 40, 60)),
}

def clamp(v): return max(0, min(255, int(v)))

def write_png(path, w, h, rows):
    raw = b"".join(b"\x00" + bytes(c for px in row for c in px) for row in rows)
    def chunk(t, d):
        c = struct.pack(">I", len(d)) + t + d
        return c + struct.pack(">I", zlib.crc32(t + d) & 0xffffffff)
    png = (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", struct.pack(">IIBBBBB", w, h, 8, 6, 0, 0, 0))
           + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))
    with open(path, "wb") as f: f.write(png)

def make(name, base, glow, eye):
    rnd = random.Random(name)
    W = H = 128
    cells = {}
    rows = []
    for y in range(H):
        row = []
        for x in range(W):
            if y >= 112 and x < 16 and y >= 114:      # area mata
                row.append((*[clamp(c + rnd.randint(-8, 8)) for c in eye], 255)); continue
            if y >= 112 and 16 <= x < 64:             # area duri
                row.append((*[clamp(c * rnd.uniform(0.8, 1.05)) for c in glow], 255)); continue
            cell = (x // 4, y // 4)
            if cell not in cells: cells[cell] = rnd.uniform(0.8, 1.2)
            f = cells[cell] * rnd.uniform(0.94, 1.06)
            if x % 4 == 0 or y % 4 == 0: f *= 0.78     # garis sisik
            px = [clamp(c * f) for c in base]
            if rnd.random() < 0.015: px = list(glow)    # bintik bercahaya
            row.append((*px, 255))
        rows.append(row)
    out = os.path.join(os.path.dirname(__file__), "..", "src", "main", "resources",
                       "assets", "kaijuwar", "textures", "entity", name + ".png")
    write_png(out, W, H, rows)

for k, (b, g, e) in KINDS.items():
    make(k, b, g, e)
print("selesai")
