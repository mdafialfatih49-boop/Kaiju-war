# Kaiju War (Fabric 1.20.1)

7 kaiju raksasa bergaya Godzilla / Pacific Rim. Tiap jenis menyerang 6 jenis lainnya.

Butuh: Minecraft Java 1.20.1, Fabric Loader, Fabric API 0.92.2+1.20.1.

## Cara build
- PC: pasang Gradle 8.5 + JDK 17, lalu jalankan `gradle build`. Jar ada di `build/libs/kaiju-war-1.0.0.jar`.
- Tanpa PC: upload semua file ini ke repo GitHub, buka tab Actions -> "build" -> Run workflow, lalu unduh artifact `kaiju-war-jar`.

## Cara main
- Telur spawn: tab kreatif "Spawn Eggs".
- Atau ketik `/kaijuwar` (butuh cheat/OP) untuk memunculkan ketujuhnya melingkar 45 blok dari kamu.
- Untuk pertarungan terbaik pakai area datar dan luas (superflat / padang rumput).
