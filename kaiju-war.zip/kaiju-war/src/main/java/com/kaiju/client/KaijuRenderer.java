package com.kaiju.client;

import com.kaiju.KaijuEntity;
import net.minecraft.client.render.entity.EntityRendererFactory;
import net.minecraft.client.render.entity.MobEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;

public class KaijuRenderer extends MobEntityRenderer<KaijuEntity, KaijuModel> {
    public KaijuRenderer(EntityRendererFactory.Context ctx) {
        super(ctx, new KaijuModel(ctx.getPart(KaijuModel.LAYER)), 2.0f);
    }

    @Override
    public Identifier getTexture(KaijuEntity entity) {
        return entity.kind.texture();
    }

    @Override
    protected void scale(KaijuEntity entity, MatrixStack matrices, float amount) {
        float s = entity.kind.scale;
        matrices.scale(s, s, s);
        this.shadowRadius = 0.8f * s;
    }
}
