package com.kaiju.client;

import com.kaiju.KaijuEntity;
import com.kaiju.KaijuWar;
import net.minecraft.client.model.ModelData;
import net.minecraft.client.model.ModelPart;
import net.minecraft.client.model.ModelPartBuilder;
import net.minecraft.client.model.ModelPartData;
import net.minecraft.client.model.ModelTransform;
import net.minecraft.client.model.TexturedModelData;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.entity.model.EntityModel;
import net.minecraft.client.render.entity.model.EntityModelLayer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.MathHelper;

/** Model dinosaurus/kaiju berkaki dua dengan ekor, duri punggung, dan rahang yang bisa terbuka. */
public class KaijuModel extends EntityModel<KaijuEntity> {
    public static final EntityModelLayer LAYER =
            new EntityModelLayer(new Identifier(KaijuWar.MOD_ID, "kaiju"), "main");

    private final ModelPart root, head, jaw, armL, armR, legL, legR, tail1, tail2, tail3;

    public KaijuModel(ModelPart root) {
        this.root = root;
        this.head = root.getChild("head");
        this.jaw = head.getChild("jaw");
        this.armL = root.getChild("arm_l");
        this.armR = root.getChild("arm_r");
        this.legL = root.getChild("leg_l");
        this.legR = root.getChild("leg_r");
        this.tail1 = root.getChild("tail1");
        this.tail2 = tail1.getChild("tail2");
        this.tail3 = tail2.getChild("tail3");
    }

    public static TexturedModelData createLayer() {
        ModelData md = new ModelData();
        ModelPartData r = md.getRoot();

        // Badan + 4 duri punggung (area tekstur duri ada di u20,v114)
        r.addChild("body", ModelPartBuilder.create()
                        .uv(0, 0).cuboid(-8, -20, -6, 16, 22, 12)
                        .uv(20, 114).cuboid(-1, -21, 6, 2, 6, 3)
                        .uv(20, 114).cuboid(-1, -14, 6, 2, 6, 3)
                        .uv(20, 114).cuboid(-1, -7, 6, 2, 6, 3)
                        .uv(20, 114).cuboid(-1, 0, 6, 2, 6, 3),
                ModelTransform.pivot(0, 12, 0));

        // Kepala + jambul + mata (area tekstur mata ada di u0,v118)
        ModelPartData head = r.addChild("head", ModelPartBuilder.create()
                        .uv(60, 0).cuboid(-5, -8, -12, 10, 9, 12)
                        .uv(20, 114).cuboid(-1, -11, -7, 2, 3, 6)
                        .uv(0, 118).cuboid(-5.4f, -8, -9, 1, 2, 2)
                        .uv(0, 118).cuboid(4.4f, -8, -9, 1, 2, 2),
                ModelTransform.pivot(0, -6, -3));
        head.addChild("jaw", ModelPartBuilder.create()
                        .uv(60, 22).cuboid(-4, 0, -11, 8, 3, 11),
                ModelTransform.pivot(0, -1, 0));

        r.addChild("arm_l", ModelPartBuilder.create().uv(30, 36).cuboid(-2, 0, -2, 4, 10, 4),
                ModelTransform.pivot(10, -4, -3));
        r.addChild("arm_r", ModelPartBuilder.create().uv(30, 36).cuboid(-2, 0, -2, 4, 10, 4),
                ModelTransform.pivot(-10, -4, -3));

        r.addChild("leg_l", ModelPartBuilder.create()
                        .uv(0, 36).cuboid(-3, 0, -4, 6, 14, 8)
                        .uv(0, 36).cuboid(-3.5f, 11, -9, 7, 3, 5),
                ModelTransform.pivot(5, 10, 0));
        r.addChild("leg_r", ModelPartBuilder.create()
                        .uv(0, 36).cuboid(-3, 0, -4, 6, 14, 8)
                        .uv(0, 36).cuboid(-3.5f, 11, -9, 7, 3, 5),
                ModelTransform.pivot(-5, 10, 0));

        // Ekor 3 segmen
        ModelPartData t1 = r.addChild("tail1", ModelPartBuilder.create()
                        .uv(0, 58).cuboid(-5, -5, 0, 10, 10, 12)
                        .uv(20, 114).cuboid(-1, -8, 2, 2, 3, 4),
                ModelTransform.pivot(0, 8, 5));
        ModelPartData t2 = t1.addChild("tail2", ModelPartBuilder.create()
                        .uv(48, 58).cuboid(-3.5f, -3.5f, 0, 7, 7, 12)
                        .uv(20, 114).cuboid(-1, -6.5f, 3, 2, 3, 4),
                ModelTransform.pivot(0, 0, 12));
        t2.addChild("tail3", ModelPartBuilder.create()
                        .uv(0, 82).cuboid(-2, -2, 0, 4, 4, 12),
                ModelTransform.pivot(0, 0, 12));

        return TexturedModelData.of(md, 128, 128);
    }

    @Override
    public void setAngles(KaijuEntity e, float limbAngle, float limbDistance, float age,
                          float headYaw, float headPitch) {
        float rad = (float) Math.PI / 180f;
        head.yaw = headYaw * rad;
        head.pitch = headPitch * rad;

        float swing = MathHelper.cos(limbAngle * 0.5f) * limbDistance;
        legL.pitch = swing;
        legR.pitch = -swing;
        armL.pitch = -swing * 0.6f;
        armR.pitch = swing * 0.6f;

        float atk = e.handSwingProgress;
        if (atk > 0f) {
            float a = MathHelper.sin(atk * (float) Math.PI);
            armL.pitch = -a * 2.2f;
            armR.pitch = -a * 2.2f;
        }

        jaw.pitch = e.isAttacking() ? 0.55f + MathHelper.sin(age * 0.5f) * 0.1f : 0.05f;

        tail1.yaw = MathHelper.sin(age * 0.08f) * 0.12f;
        tail2.yaw = MathHelper.sin(age * 0.08f - 0.6f) * 0.18f;
        tail3.yaw = MathHelper.sin(age * 0.08f - 1.2f) * 0.25f;
    }

    @Override
    public void render(MatrixStack matrices, VertexConsumer vertices, int light, int overlay,
                       float red, float green, float blue, float alpha) {
        root.render(matrices, vertices, light, overlay, red, green, blue, alpha);
    }
}
