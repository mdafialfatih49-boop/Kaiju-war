package com.kaiju.client;

import com.kaiju.Kind;
import com.kaiju.ModEntities;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;

public class KaijuWarClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        EntityModelLayerRegistry.registerModelLayer(KaijuModel.LAYER, KaijuModel::createLayer);
        for (Kind k : Kind.values()) {
            EntityRendererRegistry.register(ModEntities.TYPES.get(k), KaijuRenderer::new);
        }
    }
}
