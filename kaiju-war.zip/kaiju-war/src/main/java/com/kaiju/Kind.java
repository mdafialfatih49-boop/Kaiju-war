package com.kaiju;

import net.minecraft.util.Identifier;

public enum Kind {
    ATOMIC_TITAN("atomic_titan", 3.4f, 1000, 45, 0.26, 0x2D3237, 0x5AC8FF, false),
    BLADEHEAD("bladehead", 2.8f, 700, 60, 0.36, 0x23284B, 0xB4C8E6, false),
    STORMBACK("stormback", 3.0f, 800, 40, 0.30, 0x3C3C5A, 0xFFF050, false),
    FROSTJAW("frostjaw", 3.2f, 900, 38, 0.27, 0x6E96AA, 0xE6FAFF, false),
    MAGMA_REX("magma_rex", 3.3f, 950, 42, 0.26, 0x3C1914, 0xFF7814, true),
    VENOMTAIL("venomtail", 2.6f, 650, 35, 0.34, 0x1E4628, 0xAAFF3C, false),
    SHADOW_COLOSSUS("shadow_colossus", 2.9f, 750, 50, 0.33, 0x0F0F19, 0xA03CDC, false);

    public final String id;
    public final float scale;
    public final double health, damage, speed;
    public final int eggPrimary, eggSecondary;
    public final boolean fireImmune;

    Kind(String id, float scale, double health, double damage, double speed,
         int eggPrimary, int eggSecondary, boolean fireImmune) {
        this.id = id; this.scale = scale; this.health = health; this.damage = damage;
        this.speed = speed; this.eggPrimary = eggPrimary; this.eggSecondary = eggSecondary;
        this.fireImmune = fireImmune;
    }

    public float width() { return scale * 1.3f; }
    public float height() { return scale * 2.4f; }

    public Identifier texture() {
        return new Identifier(KaijuWar.MOD_ID, "textures/entity/" + id + ".png");
    }
}
